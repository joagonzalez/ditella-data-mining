library("futile.logger")
suppressPackageStartupMessages(library(glmnet))
library("xgboost")

import::here("glue", "glue", "glue_collapse")
import::here("pROC", "auc", "roc")
import::here("data.table",  "fwrite")

import::here("SEED_VAL", "CACHE_DIR", "RESULTS_DIR", "MAIN_LOGGER", .from = "cfg.R")
import::here("setup_logger", "log_header", .from = "utils.R")
suppressWarnings(import::here("transform", .from = "transform.R"))

logger <- glue("{MAIN_LOGGER}.fit")
set.seed(SEED_VAL)

fit_pipeline <- function(split_data = NULL, train_ratio, eval_ratio,
                         classifier = "xgb") {
    if (is.null(split_data)) {
        split_data <- transform(train_ratio = train_ratio, eval_ratio = eval_ratio)
    }

    #  TODO: Log best model params
    model <- fit_(split_data$X_train, split_data$y_train,
                 classifier = classifier)
    y_pred <- score_(model, split_data$X_test, split_data$y_test)
    df_res <- save_results_(y_pred)
    return(df_res)
}

fit_ <- function(X_train, y_train, classifier = "lr", feat_imp_length=15) {
    if (classifier == "lr") {
        flog.info("Fitting Logistic Regression...", name = logger)
        model <- cv.glmnet(X_train, y_train,
                           family = "binomial", type.measure = "auc",
                           alpha = 0.05
                          )
    } else if (classifier == "xgb") {
        flog.info("Fitting Xgboost...", name = logger)
        # ...
        flog.info(glue("Top features..."), head(feat_imp, feat_imp_length),
                  capture=TRUE, name = logger)
    }
    return(model)
}

score_ <- function(model, X_test, y_test) {
    flog.info("Computing prediction...", name = logger)
    y_pred <- predict(model, X_test, s = "lambda.min")
    flog.info("Computing AUROC...", name = logger)
    # ...
    flog.info(glue("Test AUROC: {roc_score}"), name = logger)
    return(y_pred)
}

save_results_ <- function(y_pred) {
    df_res <- data.frame("id" = seq(0, length(y_pred) - 1), "Label" = y_pred)
    res_file <- file.path(RESULTS_DIR, "results.csv")
    flog.info(glue("Saving results to {res_file}..."), name = logger)
    # ...
    return(df_res)
}


if (!interactive()) {
    if (sys.nframe() == 0) {
        library("argparse")
        parser <- ArgumentParser(description = glue("Fit Churn data and ",
                                                    "compute AUROC."))
        parser$add_argument("--train-ratio", metavar = "TRRAT",
                            type = "double", default = 0.05,
                            help = "Train ratio [default: %(default)s]")
        parser$add_argument("--eval-ratio", metavar = "TERAT",
                            type = "double", default = 0.3,
                            help = "Test ratio [default: %(default)s]")
        parser$add_argument("--classifier", metavar = "CLF",
                            default = "xgb",
                            help = "Classifier to use [default: %(default)s]")
        args <- parser$parse_args()

        setup_logger("fit.log", name = logger)
        flog.info(log_header("Fit"), name = logger)

        classifiers <- c("lr", "xgb")
        if (!is.element(args$classifier, classifiers)) {
            flog.error("Invalid classifier value. Aborting!", name = logger)
            stop(glue("classifier arg must be 'lr' or 'xgb' not ",
                      "'{args$classifier}'"))

        }

        invisible(fit_pipeline(train_ratio = args$train_ratio,
                               eval_ratio = args$eval_ratio,
                               classifier = args$classifier))
    }
}
