library("futile.logger")
suppressPackageStartupMessages(library("data.table"))

import::here("dataPreparation", "build_encoding", "one_hot_encoder")
import::here("FeatureHashing", "hashed.model.matrix")
import::here("glue", "glue", "glue_collapse")

import::here("LOG_DIR", "CACHE_DIR", "PROTECTED_COLS", "SEED_VAL",
             "MAIN_LOGGER", .from = "cfg.R")
import::here("vec_to_str", "setup_logger", "log_header", "has_col", "has_cols",
             .from = "utils.R")
import::here("extract_train_test", .from = "extract.R")

logger <- glue("{MAIN_LOGGER}.transform")
set.seed(SEED_VAL)

# --- Some helpers
filter_protected_cols_ <- function(cols, protected_cols = PROTECTED_COLS) {
    return(cols[!cols %in% protected_cols])
}

drop_cols_ <- function(dt, cols) {
    # ...
    return(dt)
}

train_test_split_ <- function(dt, phase_col = "train") {
    flog.info("Splitting data into train and test sets...", name = logger)
    if (!has_col(dt, phase_col)) {
        flog.error("Missing boolean col indicating phase. Aborting!",
                   name = logger)
        stop(glue("Required {phase_col} column not found."))
    } else {
        dt[, train := as.logical(train)]
    }
    train_dt <- subset(dt, train, select = -c(train, id))
    test_dt <- subset(dt, !train, select = -c(train, id))
    rm(dt)
    y_train <- train_dt$Label
    # ...
    split_data <- list("X_train" = X_train, "y_train" = y_train,
                       "X_test" = X_test, "y_test" = y_test)
    return(split_data)
}


# --- Actual pipeline
transform_pipeline <- function(dt, encoder = "feature_hashing",
                               hash_size = 2^20, max_null_prop = 0.7) {
    start_cols <- colnames(dt)
    flog.info(glue("Starting with the following {length(start_cols)} ",
                   "cols: {vec_to_str(start_cols)}"), name = logger)
    print(str(dt))
    dt <- drop_useless_(dt)
    gc()
    dt <- drop_duplicate_rows_(dt)
    gc()
    dt <- drop_nulls_(dt, max_null_prop = max_null_prop)
    gc()
    dt <- drop_zero_var_(dt)
    gc()
    # TODO: Add a function that computes and removes outliers
    dt <- make_new_cols_(dt)
    gc()
    dt <- ensure_dtypes_(dt)
    gc()
    dt <- fill_and_scale_numeric_(dt)
    gc()
    split_data <- encode_categorical_and_split_(dt, encoder = encoder,
                                                hash_size = hash_size)
    gc()

    return(split_data)
}

drop_useless_ <- function(dt) {
    # ...
    return(dt)
}

drop_duplicate_rows_ <- function(dt) {
    # ...
    if (nr_duplicates > 0) {
        flog.info(glue("Dropping {nr_duplicates} duplicate rows"), name = logger)
        dt <- dt[!dup_rows]
    }
    return(dt)
}

drop_nulls_ <- function(dt, max_null_prop = 0.7) {
    flog.info("Dropping null columns...", name = logger)
    na_prop <- sapply(dt, function(x) sum(is.na(x)) / length(x))
    df_na <- (data.frame(na_prop))
    df_na <- df_na[df_na$na_prop > max_null_prop, , drop = FALSE]
    df_na <- df_na[order(-df_na$na_prop), , drop = FALSE]
    flog.info(glue("Columns with more than {max_null_prop * 100}% nulls:"),
              name = logger)
    # FIXME: Log dataframe properly: this doesn't log to the file!
    flog.info("NA df", df_na, capture = TRUE, name = logger)
    dt <- drop_cols_(dt, rownames(df_na))
    return(dt)
}

drop_zero_var_ <- function(dt) {
    # ...
    return(dt)
}

make_new_cols_ <- function(dt) {
    flog.info("Creating features...", name = logger)
    dt[, creditor := ((soft_positive + hard_positive) -
                      (soft_negative + hard_negative)) > 0]

    # ...
    return(dt)
}

ensure_dtypes_ <- function(dt) {
    col_classes <- sapply(dt, class)
    bool_cols <- names(which(col_classes == "logical"))

    if (length(bool_cols)) {
        flog.info(glue("Converting the following boolean cols to factors: ",
                       "{vec_to_str(bool_cols)}..."), name = logger)
        for (c in bool_cols) {
            dt[, (c) := as.factor(get(c))]
        }
    }

    # At this stage we should only have numeric (or factor) cols
    # ...
    return(dt)
}

fill_and_scale_numeric_ <- function(dt) {
    num_cols <- colnames(dt[, .SD, .SDcols = which(sapply(dt, is.numeric))])
    cols_to_mod <- filter_protected_cols_(c(num_cols))

    flog.info("Filling null numeric values with median...", name = logger)
    # ...

    flog.info(glue("Scaling the following numeric cols: ",
                    "{vec_to_str(cols_to_mod)}..."), name = logger)
    cols_to_mod <- cols_to_mod[!cols_to_mod %in% c("soft_positive")]
    dt[, (cols_to_mod) := lapply(.SD, scale), .SDcols = cols_to_mod]
    return(dt)
}

encode_categorical_and_split_ <- function(dt, encoder = "one_hot",
                                         hash_size = 2^20) {
    cat_cols <- colnames(dt[, .SD, .SDcols = which(sapply(dt, is.factor))])
    cat_cols <- filter_protected_cols_(c(cat_cols))
    flog.info(glue("Converting cat cols from factors to characters and ",
                   "prefixing col name..."), name = logger)
    for (c in cat_cols) {
        dt[, (c) := as.character(ifelse(is.na(get(c)), "NA", get(c)))]
        dt[, (c) := paste(c, get(c), sep = "_")]
    }

    split_data <- train_test_split_(dt)
    if (encoder == "one_hot") {
        # ...

    } else if (encoder == "feature_hashing") {
        for (X_mat in c("X_train", "X_test")) {
            flog.info(glue("Encoding {X_mat}..."), name = logger)
            flog.info("Converting num cols to sparse matrix...", name = logger)
            num_cols_data <- split_data[[X_mat]][, !cat_cols, with = FALSE]
            num_cols_sparse <- as(as.matrix(num_cols_data), "dgCMatrix")
            flog.debug(glue("Num cols dimensions: ({r}, {c})",
                            r = nrow(num_cols_sparse),
                            c = ncol(num_cols_sparse)), name = logger)


            flog.info("Performing feature hashing...", name = logger)
            cat_cols_hash <- hashed.model.matrix(~.,
                                                data = split_data[[X_mat]][,
                                                cat_cols, with = FALSE],
                                                hash.size = hash_size,
                                                transpose = FALSE)
            flog.debug(glue("Hashed cat cols dimensions: ({r}, {c})",
                            r = nrow(cat_cols_hash), c = ncol(cat_cols_hash)),
                        name = logger)
            split_data[[X_mat]] <- cbind2(num_cols_sparse, cat_cols_hash)
            flog.debug(glue("{X_mat} dimensions: ({r}, {c})",
                            r = nrow(split_data[[X_mat]]),
                            c = ncol(split_data[[X_mat]])),
                        name = logger)
        }
    }

    return(split_data)
}


# --- Cli func
transform <- function(dt = NULL, train_ratio, eval_ratio,
                      encoder = "feature_hashing", hash_size = 2^20,
                      max_null_prop = 0.7, cache_dir = CACHE_DIR,
                      refresh_cache = FALSE) {

    cache_file <- file.path(cache_dir, glue("train_{train_ratio}_",
                                        "test_{eval_ratio}.rds"))
    if (file.exists(cache_file) & isFALSE(refresh_cache)) {
        # ...
    } else {
        if (is.null(dt)) {
            dt <- extract_train_test(train_ratio = train_ratio,
                                     eval_ratio = eval_ratio)
        }
        split_data <- transform_pipeline(dt, encoder = encoder,
                                        hash_size = hash_size,
                                        max_null_prop = max_null_prop)
        flog.info(glue("Saving {cache_file}..."), name = logger)
        saveRDS(split_data, cache_file)
    }
    return(split_data)
}


if (!interactive()) {
    if (sys.nframe() == 0) {
        library("argparse")
        parser <- ArgumentParser(description = "Transform Churn data.")
        parser$add_argument("--train-ratio", metavar = "TRRAT",
                            type = "double", default = 0.05,
                            help = "Train ratio [default: %(default)s]")
        parser$add_argument("--eval-ratio", metavar = "TERAT",
                            type = "double", default = 0.3,
                            help = "Eval ratio [default: %(default)s]")
        parser$add_argument("--encoder", metavar = "ENC",
                            default = "feature_hashing",
                            help = "Encoder [default: %(default)s]")
        parser$add_argument("--max-null-prop", metavar = "MAX_NULL",
                            default = 0.7,
                            help = "Max allowed nulls [default: %(default)s]")
        parser$add_argument("--refresh-cache", action = "store_true",
                            help = "Whether to refresh cache [default: %(default)s]")
        args <- parser$parse_args()

        setup_logger("transform.log", name = logger)
        flog.info(log_header("Transform"), name = logger)

        encoders <- c("one_hot", "feature_hashing")
        if (!is.element(args$encoder, encoders)) {
            flog.error("Invalid encoder value. Aborting!", name = logger)
            stop(glue("encoder arg must be 'one_hot' or 'feature_hashing' not ",
                    "'{args$encoder}'"))
        }

        invisible(transform(train_ratio = args$train_ratio,
                            eval_ratio = args$eval_ratio,
                            encoder = args$encoder,
                            max_null_prop = args$max_null_prop,
                            refresh_cache = args$refresh_cache))
    }
}
