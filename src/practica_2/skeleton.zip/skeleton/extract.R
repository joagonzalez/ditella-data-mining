library("futile.logger")

import::here("glue", "glue", "glue_collapse")
import::here("data.table", "fread", "fwrite", "rbindlist", "setcolorder")

import::here("CURR_DIR", "IN_DIR", "CACHE_DIR", "SEED_VAL", "LOG_DIR",
             "MAIN_LOGGER", .from = "cfg.R")
import::here("vec_to_str", "setup_logger", "log_header", .from = "utils.R")

# TODO: How to print more rows and columns?
# options(datatable.print.nrows=500)
logger <- glue("{MAIN_LOGGER}.extract")
set.seed(SEED_VAL)

extract_train_test <- function(in_dir = IN_DIR, train_data = NULL,
                               eval_data = NULL, test_data = NULL,
                               load_test = TRUE, train_ratio = NULL,
                               eval_ratio = NULL, drop_censored = TRUE) {
    if (is.null(train_data)) {
        train_data <- extract_phase_data(in_dir, "train",
                                         sample_ratio = train_ratio)
        if (isTRUE(drop_censored)) {
            # Drop censored dates
            train_data <- train_data[train_data[, install_date < 378]]
        }
    }
    if (is.null(eval_data)) {
        eval_data <- extract_phase_data(in_dir, "evaluation",
                                        sample_ratio = eval_ratio)
    }
    if (isTRUE(load_test) & is.null(test_data)) {
        test_data <- extract_phase_data(in_dir, "test",
                                        sample_ratio = eval_ratio)
    }

    dts <- list()
    dts[["train"]] <- train_data
    dts[["train"]]$train <- TRUE
    dts[["train"]][, Label := as.numeric(Label_max_played_dsi == 3)]
    dts[["train"]][, ("Label_max_played_dsi") := NULL]

    dts[["test"]] <- eval_data
    if (isTRUE(load_test)) {
        # ...
        dts[["test"]][test_data, on = .(id), Label := as.numeric(i.Label)]
    }
    dts[["test"]]$train <- FALSE

    dt <- rbindlist(dts, fill = TRUE)
    return(dt)
}

extract_phase_data <- function(in_dir, phase,
                            base_fn = "{phase}{extra}.csv",
                            start = 1, end = 5, span = 1,
                            sample_ratio = 1,
                            drop_cols = NULL, sel_cols = NULL,
                            cache_dir = CACHE_DIR,
                            cache_file = "{phase}_sample_{sample_ratio}.csv",
                            refresh_cache = FALSE) {
    phases <- c("train", "evaluation", "test")
    if (!is.element(phase, phases)) {
        flog.error("Invalid phase value. Aborting!", name = logger)
        stop(glue("phase arg must be 'train', 'evaluation' or 'test' not '{phase}'"))
    }

    cache_file <- file.path(cache_dir, glue(cache_file,
                                          phase = phase,
                                          sample_ratio = sample_ratio))
    if (file.exists(cache_file) & isFALSE(refresh_cache)) {
        dt <- load_csv_data_(cache_file, sample_ratio = 1,
                            drop_cols = drop_cols, sel_cols = sel_cols,
                            is_cache = TRUE)
    } else {
        in_dir <- sub("(/|\\\\)$", "", in_dir)
        if (phase == "train") {
            train_days <- seq(start, end, by = span)
            dts <- list()
            for (d in train_days) {
                csv_file <- file.path(in_dir, glue(base_fn, phase = phase,
                                                   extra = glue("_{d}", d = d)))
                dts[[d]] <- load_csv_data_(csv_file,
                                           sample_ratio = sample_ratio,
                                           drop_cols = drop_cols,
                                           sel_cols = sel_cols)
            }
            dt <- (rbindlist(dts, fill = TRUE))
        } else {
            csv_file <- file.path(in_dir, glue(base_fn, phase = phase,
                                               extra = ""))
            dt <- load_csv_data_(csv_file, sample_ratio = sample_ratio,
                                 drop_cols = drop_cols, sel_cols = sel_cols)
        }

        flog.info(glue("Saving {nrow(dt)} rows of {phase} data to ",
                       "{cache_file}..."), name = logger)
        fwrite(dt, cache_file, col.names = TRUE, sep = ",", na = "",
               showProgress = TRUE)
    }
    return(dt)
}

load_csv_data_ <- function(csv_file, sample_ratio = 1, drop_cols = NULL,
                           sel_cols = NULL, sort_cols = TRUE, is_cache = FALSE) {
    cache_indicator <- ""
    if (isTRUE(is_cache)) {
        cache_indicator <- "(cached) "
    }

    flog.info(glue("Reading {cache_indicator}data in {csv_file}..."),
                    name = logger)

    if (!is.null(sel_cols)) {
        flog.info(glue("Reading only the following columns: ",
                       "{vec_to_str(sel_cols)}"), name = logger)
    }
    if (!is.null(drop_cols)) {
        flog.info(glue("Not reading the following columns: ",
                       "{vec_to_str(drop_cols)}"), name = logger)
    }

    dt <- fread(csv_file, header = TRUE, sep = ",", stringsAsFactors = TRUE,
                na.strings = "", drop = drop_cols, select = sel_cols,
                showProgress = TRUE)
    rows <- nrow(dt)
    flog.info(glue("Read {rows} rows"), name = logger)

    if (sample_ratio < 1) {
        set.seed(SEED_VAL) # ensure seed when calling function from outside cli
        sample_size <- as.integer(sample_ratio * rows)
        flog.info(glue("Keeping a sample of {sample_size} rows ",
                       "({sample_ratio * 100}%)"), name = logger)
        dt <- dt[sample(.N, sample_size)]
    }

    if (isTRUE(sort_cols)) {
        flog.info("Sorting columns alphabetically...", name = logger)
        setcolorder(dt, sort(colnames(dt)))
    }

    return(dt)
}


if (!interactive()) {
    if (sys.nframe() == 0) {
        library("argparse")
        parser <- ArgumentParser(description = glue("Extract (load) Churn data. ",
                                 "Allows to bind and sample data."))
        parser$add_argument("--in-dir", metavar = "DIR", default = IN_DIR,
            help = "Directory with competition data [default: \"%(default)s\"]")
        parser$add_argument("--phase", default = "train",
            help = "Load train or evaluation data [default: \"%(default)s\"]")
        parser$add_argument("--sample-ratio", metavar = "RATIO",
                            type = "double", default = 0.05,
            help = "Sample ratio [default: %(default)s]")
        parser$add_argument("--refresh-cache", action = "store_true",
            help = "Whether to refresh cache [default: %(default)s]")
        args <- parser$parse_args()

        setup_logger("extract.log", name = logger)
        flog.info(log_header("Extract"), name = logger)

        in_dir <- args$in_dir
        if (!dir.exists(in_dir)) {
            flog.error(glue("in_dir arg ({in_dir}) not found. Aborting!"),
                       name = logger)
            stop(glue("{in_dir} dir not found!"))
        }

        sample_ratio <- args$sample_ratio
        if (sample_ratio > 1 || sample_ratio <= 0) {
            flog.error("Invalid sample ratio value. Aborting!", name = logger)
            stop(glue("sample_ratio value must be in (0, 1] not '{sample_ratio}'"))
        }

        invisible(extract_phase_data(in_dir, args$phase,
                                     sample_ratio = sample_ratio,
                                     refresh_cache = args$refresh_cache))
    }
}
