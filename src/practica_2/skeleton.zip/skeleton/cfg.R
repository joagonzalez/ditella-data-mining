library("futile.logger")

import::here("glue", "glue")
import::here("make_dirs", .from = "utils.R")


# Local dirs
# Note: here (and henceforth) we assume the working dir is this current file's
# directory
CURR_DIR <- getwd()
IN_DIR <- file.path(CURR_DIR, "competition-data")
tmp_dir_ <- make_dirs("tmp")
CACHE_DIR <- make_dirs(file.path(tmp_dir_, "cache"))
LOG_DIR <- make_dirs(file.path(tmp_dir_, "logs"))
RESULTS_DIR <- make_dirs(file.path(tmp_dir_, "results"))
rm(tmp_dir_)

# Data related
PROTECTED_COLS <- c("Label", "id", "train")
SEED_VAL <- 1234

# Logger
MAIN_LOGGER <- "main"
