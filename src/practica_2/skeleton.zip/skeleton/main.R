library("futile.logger")
suppressPackageStartupMessages(library(glmnet))
library("xgboost")

import::here("glue", "glue")

import::from("MAIN_LOGGER", "IN_DIR", "CACHE_DIR", .from = "cfg.R")
import::from("setup_logger", "log_header", .from = "utils.R")
import::from("extract_train_test", .from = "extract.R")
# FIXME: The next imports throw a warning
suppressWarnings(import::here("transform", .from = "transform.R"))
suppressWarnings(import::here("fit_pipeline", .from = "fit.R"))

logger <- MAIN_LOGGER
invisible(setup_logger("main.log", name = logger))

main <- function(in_dir, sample_ratio_train, sample_ratio_eval, classifier,
                 cache_dir, refresh_cache) {
    flog.info(log_header("Main"), name = logger)
    cache_file <- file.path(cache_dir, glue("train_{sample_ratio_train}_",
                                        "test_{sample_ratio_eval}.rds"))
    raw_data <- NULL
    if (!file.exists(cache_file)) {
        # ...
    }
    transformed_data <- transform(raw_data, train_ratio = sample_ratio_train,
                                  eval_ratio = sample_ratio_eval,
                                  cache_dir = cache_dir,
                                  refresh_cache = refresh_cache)
    results_data <- fit_pipeline(transformed_data,
                                 train_ratio = sample_ratio_train,
                                 eval_ratio = sample_ratio_eval,
                                 classifier = classifier)
    #  TODO: Add load to kaggle platform module
    return(results_data)
}

if (!interactive()) {
    if (sys.nframe() == 0) {
        library("argparse")
        parser <- ArgumentParser(description = "Churn prediction pipeline.")
        parser$add_argument("--in-dir", metavar = "DIR", default = IN_DIR,
            help = "Directory with competition data [default: \"%(default)s\"]")
        parser$add_argument("--train-ratio", metavar = "TRRAT", type = "double",
                            default = 0.05,
            help = "Train ratio [default: %(default)s]")
        parser$add_argument("--eval-ratio", metavar = "TERAT", type = "double",
                            default = 0.3,
            help = "Eval ratio [default: %(default)s]")
        parser$add_argument("--classifier", metavar = "CLF", default = "xgb",
            help = "Classifier to use [default: %(default)s]")
        parser$add_argument("--cache-dir", metavar = "DIR", default = CACHE_DIR,
            help = "Cache dir [default: \"%(default)s\"]")
        parser$add_argument("--refresh-cache", action = "store_true",
            help = "Whether to refresh transform cache [default: %(default)s]")
        args <- parser$parse_args()

        for (directory in c(args$in_dir,  args$cache_dir)) {
            if (!dir.exists(directory)) {
                flog.error(glue("({directory}) not found. Aborting!"),
                           name = logger)
                stop(glue("{directory} not found!"))
            }
        }

        for (sample_ratio in c(args$train_ratio,  args$eval_ratio)) {
            if (sample_ratio > 1 || sample_ratio <= 0) {
                flog.error("Invalid sample ratio value. Aborting!", name = logger)
                stop(glue("sample_ratio value must be in (0, 1] not '{sample_ratio}'"))
            }
        }

        classifiers <- c("lr", "xgb")
        if (!is.element(args$classifier, classifiers)) {
            flog.error("Invalid classifier value. Aborting!", name = logger)
            stop(glue("classifier arg must be 'lr' or 'xgb' not ",
                      "'{args$classifier}'"))

        }

        invisible(main(in_dir = args$in_dir,
                       sample_ratio_train = args$train_ratio,
                       sample_ratio_eval = args$eval_ratio,
                       classifier = args$classifier,
                       cache_dir = args$cache_dir,
                       refresh_cache = args$refresh_cache))
    }

} else {
    # For debugging
    in_dir <- IN_DIR
    sample_ratio_train <- 0.1
    sample_ratio_eval <- 0.3
    classifier <- "xgb"
    cache_dir <- CACHE_DIR
    refresh_cache <- TRUE
    main(in_dir, sample_ratio_train, sample_ratio_eval, classifier, cache_dir,
         refresh_cache)
}
