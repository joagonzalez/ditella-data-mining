import::here("glue", "glue", "glue_collapse")

make_dirs <- function(path) {
    # ...
    return(normalizePath(path))
}

vec_to_str <- function(cols, sorted = TRUE) {
    if (sorted) {
        cols <- sort(cols)
    }
    return(glue("{cols}", cols = glue_collapse(cols, ", ")))
}

setup_logger <- function(filename, name = "logger", level = "INFO") {
    flog.logger(name = name, threshold = level,
                appender = appender.tee(file.path(LOG_DIR, filename)))
    flog.layout(layout.format(glue("~t-{name}-~l:~m")), name=name)
}

log_header <- function(logger_header) {
    # ...
    return(glue(rep_str("--"), "New {logger_header} Run", rep_str("--")))
}

has_col <- function(dt, col) {
    return(is.element(col, colnames(dt)))
}

has_cols <- function(dt, cols) {
    return(all(cols %in% colnames(dt)))
}

